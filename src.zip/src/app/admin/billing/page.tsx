// src/app/admin/billing/page.tsx
"use client";

import BillingAdminPage from "@/app/admin/components/billing/BillingAdminPage";

export default function Page() {
  return <BillingAdminPage />;
}

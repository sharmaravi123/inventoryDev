import AdminInventoryManager from "../components/Inventory/InventoryManager";

export default function InventoryPage() {
  return <AdminInventoryManager />;
}
